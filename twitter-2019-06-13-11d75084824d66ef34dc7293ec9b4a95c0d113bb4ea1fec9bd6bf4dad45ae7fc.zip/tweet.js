window.YTD.tweet.part0 = [ {
  "retweeted" : false,
  "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
  "entities" : {
    "hashtags" : [ ],
    "symbols" : [ ],
    "user_mentions" : [ ],
    "urls" : [ ]
  },
  "display_text_range" : [ "0", "2" ],
  "favorite_count" : "0",
  "id_str" : "1038164571880607744",
  "truncated" : false,
  "retweet_count" : "0",
  "id" : "1038164571880607744",
  "created_at" : "Fri Sep 07 20:38:16 +0000 2018",
  "favorited" : false,
  "full_text" : "نة",
  "lang" : "ar"
} ]