window.YTD.personalization.part0 = [ {
  "p13nData" : {
    "demographics" : {
      "languages" : [ {
        "language" : "English",
        "isDisabled" : false
      } ],
      "genderInfo" : {
        "gender" : "male"
      }
    },
    "interests" : {
      "interests" : [ {
        "name" : "Comedy",
        "isDisabled" : false
      }, {
        "name" : "Comedy",
        "isDisabled" : false
      }, {
        "name" : "Computer gaming",
        "isDisabled" : false
      }, {
        "name" : "Computer reviews",
        "isDisabled" : false
      }, {
        "name" : "Dogs",
        "isDisabled" : false
      }, {
        "name" : "Human Rights",
        "isDisabled" : false
      }, {
        "name" : "Mobile",
        "isDisabled" : false
      }, {
        "name" : "Movies / Tv / Radio",
        "isDisabled" : false
      }, {
        "name" : "Music festivals and concerts",
        "isDisabled" : false
      }, {
        "name" : "Music news and general info",
        "isDisabled" : false
      }, {
        "name" : "NBA basketball",
        "isDisabled" : false
      }, {
        "name" : "Online gaming",
        "isDisabled" : false
      }, {
        "name" : "Science news",
        "isDisabled" : false
      }, {
        "name" : "Soccer",
        "isDisabled" : false
      }, {
        "name" : "Space and astronomy",
        "isDisabled" : false
      }, {
        "name" : "Sporting events",
        "isDisabled" : false
      }, {
        "name" : "Sporting goods",
        "isDisabled" : false
      }, {
        "name" : "Sports news",
        "isDisabled" : false
      }, {
        "name" : "Tech news",
        "isDisabled" : false
      } ],
      "partnerInterests" : [ ],
      "audienceAndAdvertisers" : {
        "numAudiences" : "0",
        "advertisers" : [ ]
      },
      "shows" : [ ]
    },
    "locationHistory" : [ ],
    "inferredAgeInfo" : {
      "age" : [ "13-54" ],
      "birthDate" : ""
    }
  }
} ]