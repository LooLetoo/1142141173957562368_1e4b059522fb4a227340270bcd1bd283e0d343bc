window.YTD.lists_subscribed.part0 = [ {
  "userListInfo" : {
    "urls" : [ ]
  }
} ]