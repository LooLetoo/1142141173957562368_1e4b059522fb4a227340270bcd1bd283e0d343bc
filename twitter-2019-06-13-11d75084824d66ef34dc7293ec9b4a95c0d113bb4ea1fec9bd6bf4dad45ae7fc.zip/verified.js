window.YTD.verified.part0 = [ {
  "verified" : {
    "accountId" : "1038164075832926208",
    "verified" : false
  }
} ]