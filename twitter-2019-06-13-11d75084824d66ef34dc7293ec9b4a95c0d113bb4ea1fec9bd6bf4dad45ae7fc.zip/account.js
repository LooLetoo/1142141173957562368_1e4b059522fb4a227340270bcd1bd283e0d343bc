window.YTD.account.part0 = [ {
  "account" : {
    "createdVia" : "oauth:258901",
    "username" : "r5DtnjyTTJHe6co",
    "accountId" : "1038164075832926208",
    "createdAt" : "2018-09-07T20:36:18.618Z",
    "accountDisplayName" : "رمز تأكيد تويتر الخاص بك هو 761382."
  }
} ]