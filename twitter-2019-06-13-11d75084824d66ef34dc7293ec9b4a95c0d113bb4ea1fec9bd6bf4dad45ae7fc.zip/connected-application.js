window.YTD.connected_application.part0 = [ {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter, Inc.",
      "url" : ""
    },
    "name" : "Twitter for Android",
    "description" : "Twitter for Android",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2018-09-07T20:36:18.000Z",
    "id" : "258901"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter",
      "url" : ""
    },
    "name" : "Twitter for iPhone",
    "description" : "Twitter for iPhone",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2019-05-17T20:05:34.000Z",
    "id" : "129032"
  }
}, {
  "connectedApplication" : {
    "organization" : {
      "name" : "Twitter, Inc.",
      "url" : ""
    },
    "name" : "Twitter for Android",
    "description" : "Twitter for Android",
    "permissions" : [ "read", "write" ],
    "approvedAt" : "2019-06-12T10:59:35.000Z",
    "id" : "258901"
  }
} ]