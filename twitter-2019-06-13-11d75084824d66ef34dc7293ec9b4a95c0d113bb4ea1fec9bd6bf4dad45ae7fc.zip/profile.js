window.YTD.profile.part0 = [ {
  "profile" : {
    "description" : {
      "bio" : "",
      "website" : "",
      "location" : ""
    },
    "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1038164877280530432/KM26obKW.jpg"
  }
} ]